<?php
// Strings starting with '%'  will be automatically replaced by script. Do not translate these
//
// ----------------------------------------
// utf-8 charset
// Translation of cz-language.php  by:
// Marek �apla <marek.capla(at)centrum(dot)cz>
// ----------------------------------------

$sph_messages =  Array (
  "Categories" => "Kategorie",
  "CATEGORIES" => "KATEGORIE",
  "Untitled" => "Nepojmenovan� dokument",
  "Powered by" => "Pou��v�",
  "Previous" => "Vzad",
  "Next" => "Vp�ed",
  "Result page" => "Str�nka v�sledk�",
  "Only in category" => "Jen v kategorii",
  "Search" => "Vyhledat",
  "All sites" => "V�echny str�nky",
  "Web pages" => "Web str�nky",
  "noMatch" => "Nebyl nelezen ��dn� dokument vyhovuj�c� v�razu &bdquo;%query&rdquo;",
  "ignoredWords" => "N�sleduj�c� slova byly ignorovan� (p��li� kr�tk� nebo v�eobecn�): %ignored_words",
  "resultsFor" => "V�sledky pro:",
  "Results" => "Zobrazuj� se v�sledky %from &ndash; %to z %all %matchword (%secs sekundy) ", //matchword will be replaced by match or matches (from this file), depending on the number of results.
  "match" => "v�skyt",
  "matches" => "v�skyt�",
  "andSearch" => "AND vyhlad�v�n�",
  "orSearch" => "OR vyhled�v�n�",
  "phraseSearch" => "Vyhled�v�n� fr�ze",
  "show" => "Zobrazit ",
  "resultsPerPage" => "v�sledk� na str�nku",
	"DidYouMean" => "Mysl�"
);
?>
