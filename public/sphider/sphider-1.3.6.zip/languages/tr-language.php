<?
// Strings starting with '%'  will be automatically replaced by script. Do not translate these
$sph_messages =  Array (
	"Categories" => "Kategoriler",
	"CATEGORIES" => "Kategoriler",
	"Untitled" => "Untitled document",
	"Powered by" => "Powered by",
	"Previous" => "Geri",
	"Next" => "�leri",
	"Result page" => "Bulunan Sayfalar",
	"Only in category" => "Sadece kategori",
	"Search" => "Arama Yap",
	"All sites" => "B�t�n Siteler",
	"Web pages" => "Web Sayfalar�",
	"noMatch" => "Arama Sonucunda \"%query\" Konu �le �lgili Bir Dokuman Bulunamam��t�r.", 
	"ignoredWords" => "Following words were ignored (too short or common): %ignored_words",
	"resultsFor" => "��in sonu�lar:",
	"Results" => "Arama Sonucunda %from - %to ve %all %matchword (%secs seconds) ", //matchword will be replaced by match or matches (from this file), depending on the number of results.
	"match" => "Sonu�",     
	"matches" => "G�r�nt�lenmektedir.", 
	"andSearch" => "ve arama yap",         
	"orSearch" => "veya aramaya devam et",    
	"phraseSearch" => "S�zc�k grubu arar",
	"show" => "G�ster ",
	"resultsPerPage" => "Sayfa Ba�� olan Sonu�lar",
	"DidYouMean" => "Did you mean"
);
?>
