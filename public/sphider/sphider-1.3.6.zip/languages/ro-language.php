
<?php 
$sph_messages =  Array (
	"Categories" => "Categorie",
	"CATEGORIES" => "CATEGORII",
	"Untitled" => "Document necunoscut",
	"Powered by" => "Sponsorizat de",
	"Previous" => "Inapoi",
	"Next" => "Urmatorul",
	"Result page" => "Pagina cu rezulatate",
	"Only in category" => "Doar intr-o categorie",
	"Search" => "Cauta",
	"All sites" => "Toate Site-urile",
	"Web pages" => "Pagini web",
	"noMatch" => "Cautarea \"%query\" nu s-a gasit nimic",
	"ignoredWords" => "Urmatoarele cuvinte au fost ignorate (prea putin sau obisnuit): %ignored_words",
	"resultsFor" => "Rezultate pentru:",
	"Results" => "Rezultate %from - %to de %all %matchword (%secs secunde)", //
	"match" => "gasit",     //
	"matches" => "s-a gasit", //
	"andSearch" => "Si Cauta",         
	"orSearch" => "SAU Cauta",    
	"phraseSearch" => "Cauta Fraza",
	"show" => "Arata ",
	"resultsPerPage" => "Rezultate pe pagina",
	"DidYouMean" => "Did you mean"
    //This file was made by Chitiga Georges (NaKeDMaN) nakedman@arcshells.ro WwW.FreeDownloads.Lx.Ro
);
?>