<?php 
$sph_messages =  Array (
	"Categories" => "Kategorije",
	"CATEGORIES" => "Kategorije",
	"Untitled" => "Dokument bez naslova",
	"Powered by" => "Powered by",
	"Previous" => "Prethodna",
	"Next" => "Slijede�a",
	"Result page" => "Rezultati",
	"Only in category" => "Samo u kategoriji",
	"Search" => "Pretra�i",
	"All sites" => "Sve stranice",
	"Web pages" => "Web stranice",
	"noMatch" => "Pretra�ivanje \"%query\" nije rezultiralo prona�enim dokumentima",
	"ignoredWords" => "Slijede�e rije�i bile su ignorirane (prekratke ili u�estale): %ignored_words",
	"resultsFor" => "Rezultati za:",
	"Results" => "Pokazano rezultata %from - %to od %all %matchword (%secs sekunde)", //
	"match" => "prona�enih",     //
	"matches" => "prona�enih", //
	"andSearch" => "I tra�i",         
	"orSearch" => "ILI tra�i",    
	"phraseSearch" => "Tra�i frazu",
	"show" => "Prika�i ",
	"resultsPerPage" => "rezultata po stranici",
	"DidYouMean" => "Did you mean"
);
?>