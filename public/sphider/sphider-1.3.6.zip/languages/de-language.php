<?php 
$sph_messages =  Array (
	"Categories" => "Kategorien",
	"CATEGORIES" => "KATEGORIEN",
	"Untitled" => "Unbenanntes Dokument",
	"Powered by" => "�bersetzung by: <a href=\"mailto:sk38@uni.de\">Sascha Kuhn</a> Script by: ",
	"Previous" => "Vorherige",
	"Next" => "N�chste",
	"Result page" => "Ergebniss Seite",
	"Only in category" => "Nur in Kategorie",
	"Search" => "Suche",
	"All sites" => "Alle Seiten",
	"Web pages" => "Web seiten",
	"noMatch" => "Die Suche \"%query\" ergab keine Ergebnisse",
	"ignoredWords" => "Folgende W�rter wurden ignoriert: %ignored_words",
	"resultsFor" => "Ergebnisse f�r:",
	"Results" => "Zeige Seiten %from - %to von %all %matchword (%secs Sekunden)", //
	"match" => "match",     //
	"matches" => "Ergebnisse", //
	"seconds" => "Sekunden",
	"andSearch" => "AND Search",         
	"orSearch" => "OR Search",    
	"phraseSearch" => "Phrase Search",
	"show" => "Show ",
	"resultsPerPage" => "results per page",
	"DidYouMean" => "Did you mean"

);
?>