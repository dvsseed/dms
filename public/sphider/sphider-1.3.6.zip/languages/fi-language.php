<?php 
// Strings starting with '%'  will be automatically replaced by script. Do not translate these
$sph_messages =  Array (
	"Categories" => "Luokat",
	"CATEGORIES" => "LUOKAT",
	"Untitled" => "Otsikoimaton",
	"Powered by" => "Hakukoneena",
	"Previous" => "Edellinen",
	"Next" => "Seuraava",
	"Result page" => "Tulossivu",
	"Only in category" => "vain luokasta",
	"Search" => "Etsi",
	"All sites" => "kaikista sivustoista",
	"Web pages" => "Verkkosivuja",
	"noMatch" => "Hakusana - %query - ei tuottanut osumia", 
	"ignoredWords" => "Seuraavia sanoja ei huomioitu haussa (liian lyhyt tai yleinen): %ignored_words",
	"resultsFor" => "Hakutuloksia:",
	"Results" => "Tulokset %from - %to kaikkiaan %all %matchword (%secs sekuntia) ", //matchword will be replaced by match or matches (from this file), depending on the number of results.
	"match" => "osuman joukosta",     
	"matches" => "osuman joukosta", 
	"andSearch" => "kaikilla sanoilla",         
	"orSearch" => "mill� tahansa sanoista",    
	"phraseSearch" => "t�sm�llisell� ilmauksella",
	"show" => "n�yt� ",
	"resultsPerPage" => "tulosta sivulla",
	"DidYouMean" => "Did you mean"
);
?>